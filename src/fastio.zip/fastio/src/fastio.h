//
// fastio.h
//

/*
  This file is part of FIRSTIO library for the Arduino.
  
  FASTIO library was developed by Synapse(Hiroshi Tanigawa) in 2019.
  This Library is originally distributed at "Synapse's history of making 
  gadgets."  <https://synapse.kyoto>

  FASTIO library is now under beta testing, so specification may be changed 
  in the future.

  FASTIO library is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation, either version 2.1 of the License, or
  (at your option) any later version.

  FASTIO library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with FASTIO library.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __FASTIO_H__
#define __FASTIO_H__

#include <arduino.h>

#if(__cplusplus<201103L)
#error This program requires C++11. Use newer ARDUINO IDE.
#endif

#if    defined(__AVR_ATmega48__)|| defined(__AVR_ATmega48P__)  || defined(__AVR_ATmega88__) || defined(__AVR_ATmega88P__)|| defined(__AVR_ATmega168__)|| defined(__AVR_ATmega168P__) || defined(__AVR_ATmega328__) || defined(__AVR_ATmega328P__)
#define ARDUINO_STANDARD
#endif

#ifndef ARDUINO_STANDARD
#error this program is only for standard Arduino.
#endif

#define FASTIO_VERSION (100L) // version 0.1.0

#define LOWBYTEFIRST 2
#define HIGHBYTEFIRST 4

#include "utility/gpio.h"
#include "utility/hc595.h"
#include "utility/hc165.h"

#endif
