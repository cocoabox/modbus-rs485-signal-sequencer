//
// gpio.h
//

/*
  This file is part of FIRSTIO library for the Arduino.
  
  FASTIO library was developed by Synapse(Hiroshi Tanigawa) in 2019.
  This Library is originally distributed at "Synapse's history of making 
  gadgets."  <https://synapse.kyoto>

  FASTIO library is now under beta testing, so specification may be changed 
  in the future.

  FASTIO library is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation, either version 2.1 of the License, or
  (at your option) any later version.

  FASTIO library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with FASTIO library.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __GPIO_H__
#define __GPIO_H__

#include <arduino.h>

uint16_t constexpr pin_to_PORT_address(uint8_t pin)
{
  return pin< 8 ? (uint16_t)&PORTD :
         pin<14 ? (uint16_t)&PORTB : 
         pin<20 ? (uint16_t)&PORTC : 
         NULL;
} // pin_to_PORT_address

uint16_t constexpr pin_to_PIN_address(uint8_t pin)
{
  return pin< 8 ? (uint16_t)&PIND :
         pin<14 ? (uint16_t)&PINB : 
         pin<20 ? (uint16_t)&PINC : 
         NULL;
} // pin_to_PIN_address

uint8_t constexpr pin_to_mask(uint8_t pin)
{
  return pin< 8 ? _BV(pin)    : // PORTD
         pin<14 ? _BV(pin-8)  : // PORTB
         pin<20 ? _BV(pin-14) : // PORTC
         -1;
} // pin_to_mask

template<uint8_t pin> void digitalWrite(uint8_t value) __attribute__((always_inline));
template<uint8_t pin> uint8_t digitalRead(void) __attribute__((always_inline));

template<uint8_t pin> void digitalWrite(uint8_t value)
{
  static_assert(pin_to_PORT_address(pin)!=NULL,"invalid pin number.");
  volatile uint8_t &PORT=*reinterpret_cast<uint8_t *>(pin_to_PORT_address(pin));
  constexpr uint8_t mask=pin_to_mask(pin);
  if(value==LOW) {
    PORT&=~mask;
  } else {
    PORT|= mask;
  } // if
} // digitalWrite

template<uint8_t pin> uint8_t digitalRead(void)
{
  static_assert(pin_to_PIN_address(pin)!=NULL,"invalid pin number.");
  volatile uint8_t &PIN=*(uint8_t *)pin_to_PIN_address(pin);
  constexpr uint8_t mask=pin_to_mask(pin);
  return (PIN&mask)!=LOW;
} // digitalRead

template<uint8_t pinNo> class fastIoPin {
  public:
  void digitalWrite(int value) const __attribute__((always_inline)) { ::digitalWrite<pinNo>(value); }
  int digitalRead(void) __attribute__((always_inline)) { return ::digitalRead<pinNo>(); }
  int operator=(int value) const __attribute__((always_inline)) { digitalWrite(value); return value; }
  operator int() const __attribute__((always_inline)) { return digitalRead(); } 
  void pinMode(int value) const { ::pinMode(pinNo, value); }
}; // fastIoPin

#endif
