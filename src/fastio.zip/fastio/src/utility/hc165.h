//
// hc165.h
//

/*
  This file is part of FIRSTIO library for the Arduino.
  
  FASTIO library was developed by Synapse(Hiroshi Tanigawa) in 2019.
  This Library is originally distributed at "Synapse's history of making 
  gadgets."  <https://synapse.kyoto>

  FASTIO library is now under beta testing, so specification may be changed 
  in the future.

  FASTIO library is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation, either version 2.1 of the License, or
  (at your option) any later version.

  FASTIO library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with FASTIO library.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __HC165_H__
#define __HC165_H__

#include "gpio.h"

template <uint8_t qh, uint8_t clk, uint8_t sh, uint8_t byteNum, uint8_t bitOrder=LSBFIRST, uint8_t byteOrder=LOWBYTEFIRST>
class hc165 {
  static_assert(byteOrder==LOWBYTEFIRST || byteOrder==HIGHBYTEFIRST,"invalid byte order.");
  static_assert(bitOrder==LSBFIRST || bitOrder==MSBFIRST,"invalid bit order.");
  static_assert(qh!=clk && clk!=sh && sh!=qh,"invalid pin assign.");

  private:
  uint8_t buf[byteNum];

  public:
  void init(void) const;
  void fetch(void);
  uint32_t shiftIn(void);
  uint8_t digitalRead(uint8_t bitNo);
  uint8_t readFromBuffer(uint8_t bitNo) const;
  template <uint8_t bitNo> uint8_t digitalRead(void);
  template <uint8_t bitNo> uint8_t readFromBuffer(void) const;
  operator int() { return shiftIn(); }
}; // hc165

template <uint8_t qh, uint8_t clk, uint8_t sh, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
void hc165<qh, clk, sh, byteNum, bitOrder, byteOrder>::init(void) const
{
  pinMode(qh, INPUT);
  pinMode(clk, OUTPUT);
  pinMode(sh, OUTPUT);

  ::digitalWrite<clk>(LOW);
  ::digitalWrite<sh>(HIGH);
} // hc165::init

template <uint8_t qh, uint8_t clk, uint8_t sh, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
void hc165<qh, clk, sh, byteNum, bitOrder, byteOrder>::fetch(void)
{
  class localFunc {
    public:
    static int readBit(uint8_t &data, uint8_t mask) __attribute__((always_inline)) { if(::digitalRead<qh>()) data|=mask; ::digitalWrite<clk>(HIGH); ::digitalWrite<clk>(LOW); };   
  }; // class
  
  ::digitalWrite<sh>(LOW);
  ::digitalWrite<sh>(HIGH);
 
  for(uint8_t i=0; i<byteNum; i++) {
    uint8_t data=0;

    if(bitOrder==LSBFIRST) {
      localFunc::readBit(data, 0x01);
      localFunc::readBit(data, 0x02);
      localFunc::readBit(data, 0x04);
      localFunc::readBit(data, 0x08);
      localFunc::readBit(data, 0x10);
      localFunc::readBit(data, 0x20);
      localFunc::readBit(data, 0x40);
      localFunc::readBit(data, 0x80);
    } else {
      localFunc::readBit(data, 0x80);
      localFunc::readBit(data, 0x40);
      localFunc::readBit(data, 0x20);
      localFunc::readBit(data, 0x10);
      localFunc::readBit(data, 0x08);
      localFunc::readBit(data, 0x04);
      localFunc::readBit(data, 0x02);
      localFunc::readBit(data, 0x01);
    } // if
    if(byteOrder==LOWBYTEFIRST) {
      buf[i]=data;
    } else {
      buf[byteNum-1-i]=data;
    } // if
  } // for i
} // hc165::fetch

template <uint8_t qh, uint8_t clk, uint8_t sh, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
uint32_t hc165<qh, clk, sh, byteNum, bitOrder, byteOrder>::shiftIn(void)
{
  uint32_t data=0;
  fetch();
  for(int i=0; i<byteNum; i++) {
    data=(data<<8) | buf[byteNum-1-i];
  } // for i
  return data;
} // hc165::shiftIn

template <uint8_t qh, uint8_t clk, uint8_t sh, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
uint8_t hc165<qh, clk, sh, byteNum, bitOrder, byteOrder>::digitalRead(uint8_t bitNo)
{
  fetch();
  return (buf[bitNo>>3] & (1<<(bitNo & 7))) ? HIGH : LOW;
} // hc165::digitalRead

template <uint8_t qh, uint8_t clk, uint8_t sh, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
uint8_t hc165<qh, clk, sh, byteNum, bitOrder, byteOrder>::readFromBuffer(uint8_t bitNo) const
{
  return (buf[bitNo>>3] & (1<<(bitNo & 7))) ? HIGH : LOW;
} // hc165::readFromBuffer

template <uint8_t qh, uint8_t clk, uint8_t sh, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
template <uint8_t bitNo>
uint8_t hc165<qh, clk, sh, byteNum, bitOrder, byteOrder>::digitalRead(void)
{
  fetch();
  return (buf[bitNo>>3] & (1<<(bitNo & 7))) ? HIGH : LOW;
} // hc165::digitalRead

template <uint8_t qh, uint8_t clk, uint8_t sh, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
template <uint8_t bitNo>
uint8_t hc165<qh, clk, sh, byteNum, bitOrder, byteOrder>::readFromBuffer(void) const
{
  return (buf[bitNo>>3] & (1<<(bitNo & 7))) ? HIGH : LOW;
} // hc165::readFromBuffer

template<class _hc165, _hc165 &driver, int bitNo>
class hc165pin{
  public:
  uint8_t digitalRead(void) const { return driver.digitalRead(bitNo); }
  uint8_t readFromBuffer(void) const { return driver.readFromBuffer(bitNo); }
  operator int(void) const { return driver.digitalRead(bitNo); }
}; // hc165pin

#endif
