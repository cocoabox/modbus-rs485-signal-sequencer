//
// hc595.h
//

/*
  This file is part of FIRSTIO library for the Arduino.
  
  FASTIO library was developed by Synapse(Hiroshi Tanigawa) in 2019.
  This Library is originally distributed at "Synapse's history of making 
  gadgets."  <https://synapse.kyoto>

  FASTIO library is now under beta testing, so specification may be changed 
  in the future.

  FASTIO library is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation, either version 2.1 of the License, or
  (at your option) any later version.

  FASTIO library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License
  along with FASTIO library.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __HC595_H__
#define __HC595_H__

#include "gpio.h"

template <uint8_t ser, uint8_t srclk, uint8_t rclk, uint8_t byteNum=1, uint8_t bitOrder=LSBFIRST, uint8_t byteOrder=LOWBYTEFIRST>
class hc595 {
  static_assert(byteOrder==LOWBYTEFIRST || byteOrder==HIGHBYTEFIRST,"invalid byte order.");
  static_assert(bitOrder==LSBFIRST || bitOrder==MSBFIRST,"invalid bit order.");
  static_assert(ser!=srclk && srclk!=rclk && rclk!=ser,"invalid pin assign.");

  private:
  uint8_t buf[byteNum];

  public:
  void init(void);
  void flush() const;
  void shiftOut(uint32_t value);
  uint32_t operator=(uint32_t value) __attribute__((always_inline)) { shiftOut(value); return value; }
  void digitalWrite(uint8_t bitNo, uint8_t value) { writeToBuffer(bitNo, value); flush(); }
  void writeToBuffer(uint8_t bitNo, uint8_t value);
  template <uint8_t bitNo> void digitalWrite(uint8_t value) { writeToBuffer<bitNo>(value); flush(); }
  template <uint8_t bitNo> void writeToBuffer(uint8_t value);
}; // hcC595

template <uint8_t ser, uint8_t srclk, uint8_t rclk, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
void hc595<ser, srclk, rclk, byteNum, bitOrder, byteOrder>::init(void)
{
  pinMode(ser,OUTPUT);
  pinMode(srclk,OUTPUT);
  pinMode(rclk,OUTPUT);
  ::digitalWrite<srclk>(LOW);
  ::digitalWrite<rclk>(LOW);
  for(int i=0; i<byteNum; i++) buf[i]=0;
  flush();
} // hc595::hc595

template <uint8_t ser, uint8_t srclk, uint8_t rclk, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
void hc595<ser, srclk, rclk, byteNum, bitOrder, byteOrder>::flush() const
{
  class localFunc{
    public:
    static void sendBit(uint8_t d) __attribute__((always_inline)) { ::digitalWrite<ser>(d); ::digitalWrite<srclk>(HIGH); ::digitalWrite<srclk>(LOW); };
  }; // sendBit
  
  for(int i=0; i<byteNum; i++) {
    uint8_t data;
    if(byteOrder==LOWBYTEFIRST) {
      data=buf[i];
    } else {
      data=buf[byteNum-1-i];
    } // if
    
    if(bitOrder==LSBFIRST) {
      localFunc::sendBit(data & 0x01);
      localFunc::sendBit(data & 0x02);
      localFunc::sendBit(data & 0x04);
      localFunc::sendBit(data & 0x08);
      localFunc::sendBit(data & 0x10);
      localFunc::sendBit(data & 0x20);
      localFunc::sendBit(data & 0x40);
      localFunc::sendBit(data & 0x80);
    } else {
      localFunc::sendBit(data & 0x80);
      localFunc::sendBit(data & 0x40);
      localFunc::sendBit(data & 0x20);
      localFunc::sendBit(data & 0x10);
      localFunc::sendBit(data & 0x08);
      localFunc::sendBit(data & 0x04);
      localFunc::sendBit(data & 0x02);
      localFunc::sendBit(data & 0x01);
    } // if
  } // for i
  ::digitalWrite<rclk>(HIGH);
  ::digitalWrite<rclk>(LOW);
} // hc595::flush

template <uint8_t ser, uint8_t srclk, uint8_t rclk, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
void hc595<ser, srclk, rclk, byteNum, bitOrder, byteOrder>::shiftOut(uint32_t value)
{
  for(int i=0; i<byteNum; i++) {
    buf[i]=value & 0xffu;
    value>>=8;
  } // for i
  flush();
} // hc595::shiftOut

template <uint8_t ser, uint8_t srclk, uint8_t rclk, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
void hc595<ser, srclk, rclk, byteNum, bitOrder, byteOrder>::writeToBuffer(uint8_t bitNo, uint8_t value)
{
  if(value) {
    buf[bitNo >> 3] |= (1 << (bitNo & 7));
  } else {
    buf[bitNo >> 3] &= ~(1 << (bitNo & 7));
  } // if
} // hc595::writeToBuffer

template <uint8_t ser, uint8_t srclk, uint8_t rclk, uint8_t byteNum, uint8_t bitOrder, uint8_t byteOrder>
template <uint8_t bitNo>
void hc595<ser, srclk, rclk, byteNum, bitOrder, byteOrder>::writeToBuffer(uint8_t value)
{
  if(value) {
    buf[bitNo >> 3] |= (1 << (bitNo & 7));
  } else {
    buf[bitNo >> 3] &= ~(1 << (bitNo & 7));
  } // if
} // hc595::writeToBuffer

template<class _hc595, _hc595 &driver, uint8_t bitNo>
class hc595pin {
  public:
  void digitalWrite(uint8_t value) const { driver.digitalWrite(bitNo, value); }
  int operator=(uint8_t value) const { driver.digitalWrite(bitNo, value); return value; }
  void writeToBuffer(uint8_t value) const { driver.writeToBuffer(bitNo, value); }
}; // hc595pin

#endif
